library("rstan")

schools=read.table("schoolsdata.txt",header=TRUE)
schools
#  school estimate sd
#1      A       28 15
#2      B        8 10
#3      C       -3 16
#4      D        7 11
#5      E       -1  9
#6      F        1 11
#7      G       18 10
#8      H       12 18
y=schools$estimate
y
#[1] 28  8 -3  7 -1  1 18 12

J = nrow(schools)
y = schools$estimate
sigma = schools$sd

schools_fit <- stan(file="schools.stan", data=c("J","y","sigma"), iter=1000, chains=4)
print(schools_fit)
plot(schools_fit)

# HW: try composition method in R
# (a) plot p(tau|y)
# (b) plot E(theta_i|tau,y)   using equation (5.17)
# (c) plot sqrt(Var(theta_i|mu,tau,y))   using equation (5.17)
